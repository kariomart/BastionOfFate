﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateLevel : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
		GenerateRooms ();
		// SpawnItems ();
		// CreateDoors ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	void GenerateRooms () {
		
	}
}
