﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class General : Card {

	public  General() {
		name = "The General";
		health = 5; 
	}



}
